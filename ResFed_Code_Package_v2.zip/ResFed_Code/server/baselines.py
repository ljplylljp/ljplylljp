"""
经典拜占庭鲁棒聚合基线实现
Krum, Multi-Krum, Coordinate-wise Median, Trimmed Mean
"""
import numpy as np
from typing import List, Tuple, Optional, Dict
from flwr.server.strategy import FedAvg
from flwr.common import Parameters, FitRes, Scalar, ndarrays_to_parameters, parameters_to_ndarrays
from flwr.server.client_proxy import ClientProxy
from typing import Union


def _flatten(weights: List[np.ndarray]) -> np.ndarray:
    return np.concatenate([w.flatten() for w in weights])


def _unflatten(flat: np.ndarray, shapes: List[tuple]) -> List[np.ndarray]:
    result = []
    offset = 0
    for shape in shapes:
        size = int(np.prod(shape))
        result.append(flat[offset:offset+size].reshape(shape))
        offset += size
    return result


class KrumStrategy(FedAvg):
    """Krum / Multi-Krum aggregation"""
    def __init__(self, num_malicious: int = 2, multi_krum: bool = False, **kwargs):
        super().__init__(**kwargs)
        self.num_malicious = num_malicious
        self.multi_krum = multi_krum

    def aggregate_fit(self, server_round, results, failures):
        if not results:
            return None, {}
        weights_results = [parameters_to_ndarrays(fit_res.parameters) for _, fit_res in results]
        n = len(weights_results)
        if n <= self.num_malicious + 2:
            # fallback
            return super().aggregate_fit(server_round, results, failures)

        flats = [_flatten(w) for w in weights_results]
        shapes = [w.shape for w in weights_results[0]]

        # pairwise distances
        distances = np.zeros((n, n))
        for i in range(n):
            for j in range(i+1, n):
                dist = np.linalg.norm(flats[i] - flats[j])
                distances[i, j] = distances[j, i] = dist

        scores = []
        for i in range(n):
            dists = np.sort(distances[i])
            # sum of distances to n - f - 2 nearest
            score = np.sum(dists[1:n - self.num_malicious - 1])
            scores.append(score)

        if self.multi_krum:
            selected = np.argsort(scores)[:n - self.num_malicious]
        else:
            selected = [np.argmin(scores)]

        selected_weights = [weights_results[i] for i in selected]
        # average selected
        aggregated = [np.mean([w[k] for w in selected_weights], axis=0) for k in range(len(shapes))]
        return ndarrays_to_parameters(aggregated), {"selected": len(selected)}


class MedianStrategy(FedAvg):
    """Coordinate-wise Median"""
    def aggregate_fit(self, server_round, results, failures):
        if not results:
            return None, {}
        weights_results = [parameters_to_ndarrays(fit_res.parameters) for _, fit_res in results]
        aggregated = []
        for layer_idx in range(len(weights_results[0])):
            stacked = np.stack([w[layer_idx] for w in weights_results], axis=0)
            median = np.median(stacked, axis=0)
            aggregated.append(median)
        return ndarrays_to_parameters(aggregated), {}


class TrimmedMeanStrategy(FedAvg):
    """Trimmed Mean: remove beta fraction largest and smallest"""
    def __init__(self, beta: float = 0.1, **kwargs):
        super().__init__(**kwargs)
        self.beta = beta

    def aggregate_fit(self, server_round, results, failures):
        if not results:
            return None, {}
        weights_results = [parameters_to_ndarrays(fit_res.parameters) for _, fit_res in results]
        n = len(weights_results)
        k = int(n * self.beta)
        aggregated = []
        for layer_idx in range(len(weights_results[0])):
            stacked = np.stack([w[layer_idx] for w in weights_results], axis=0)
            # sort along client axis
            sorted_stack = np.sort(stacked, axis=0)
            if k > 0 and 2*k < n:
                trimmed = sorted_stack[k:n-k]
            else:
                trimmed = sorted_stack
            mean = np.mean(trimmed, axis=0)
            aggregated.append(mean)
        return ndarrays_to_parameters(aggregated), {}
