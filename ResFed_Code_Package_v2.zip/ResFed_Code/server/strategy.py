import numpy as np
from typing import List, Tuple, Dict, Optional, Union
from flwr.server.strategy import FedAvg
from flwr.common import (
    Parameters,
    FitRes,
    Scalar,
    ndarrays_to_parameters,
    parameters_to_ndarrays,
)
from flwr.server.client_proxy import ClientProxy
from sklearn.ensemble import IsolationForest
from copy import deepcopy


def extract_features(updates: List[List[np.ndarray]], global_params: Optional[List[np.ndarray]] = None) -> np.ndarray:
    """
    Extract residual-based features from client updates.
    Features: L2 norm, mean, std, max abs, cosine similarity to mean update
    """
    features = []
    flat_updates = []
    for update in updates:
        flat = np.concatenate([u.flatten() for u in update])
        flat_updates.append(flat)
    
    flat_updates = np.array(flat_updates)
    mean_update = np.mean(flat_updates, axis=0)
    
    for flat in flat_updates:
        norm = np.linalg.norm(flat)
        mean_val = np.mean(flat)
        std_val = np.std(flat)
        max_abs = np.max(np.abs(flat))
        # cosine similarity to mean
        cos_sim = np.dot(flat, mean_update) / (np.linalg.norm(flat) * np.linalg.norm(mean_update) + 1e-8)
        features.append([norm, mean_val, std_val, max_abs, cos_sim])
    
    return np.array(features)


class ResidualRobustStrategy(FedAvg):
    """
    Residual-based Robust Federated Aggregation Strategy.
    Detects malicious clients via IsolationForest on residual features,
    then aggregates only benign updates.
    """
    def __init__(
        self,
        *,
        contamination: float = 0.2,
        min_fit_clients: int = 2,
        min_available_clients: int = 2,
        fraction_fit: float = 1.0,
        fraction_evaluate: float = 1.0,
        min_evaluate_clients: int = 2,
        initial_parameters: Optional[Parameters] = None,
        evaluate_fn=None,
        on_fit_config_fn=None,
        on_evaluate_config_fn=None,
        accept_failures: bool = True,
        fit_metrics_aggregation_fn=None,
        evaluate_metrics_aggregation_fn=None,
        inplace: bool = True,
    ):
        super().__init__(
            fraction_fit=fraction_fit,
            fraction_evaluate=fraction_evaluate,
            min_fit_clients=min_fit_clients,
            min_evaluate_clients=min_evaluate_clients,
            min_available_clients=min_available_clients,
            evaluate_fn=evaluate_fn,
            on_fit_config_fn=on_fit_config_fn,
            on_evaluate_config_fn=on_evaluate_config_fn,
            accept_failures=accept_failures,
            initial_parameters=initial_parameters,
            fit_metrics_aggregation_fn=fit_metrics_aggregation_fn,
            evaluate_metrics_aggregation_fn=evaluate_metrics_aggregation_fn,
            inplace=inplace,
        )
        self.contamination = contamination
        self.detector = IsolationForest(
            contamination=contamination,
            random_state=42,
            n_estimators=100,
        )
        self.global_params_history = []
        self.detection_history = []

    def aggregate_fit(
        self,
        server_round: int,
        results: List[Tuple[ClientProxy, FitRes]],
        failures: List[Union[Tuple[ClientProxy, FitRes], BaseException]],
    ) -> Tuple[Optional[Parameters], Dict[str, Scalar]]:
        if not results:
            return None, {}

        # Convert to ndarrays
        weights_results = [
            (parameters_to_ndarrays(fit_res.parameters), fit_res.num_examples)
            for _, fit_res in results
        ]
        updates = [w for w, _ in weights_results]
        num_examples = [n for _, n in weights_results]

        # Extract residual features
        features = extract_features(updates)
        
        # Fit detector and predict (1 = benign, -1 = malicious)
        try:
            preds = self.detector.fit_predict(features)
        except Exception:
            # Fallback if detection fails
            preds = np.ones(len(updates))

        benign_mask = preds == 1
        num_benign = np.sum(benign_mask)
        num_malicious_detected = len(preds) - num_benign

        self.detection_history.append({
            "round": server_round,
            "detected_malicious": int(num_malicious_detected),
            "total_clients": len(preds),
        })

        # Select only benign updates
        if num_benign >= max(2, int(0.3 * len(updates))):
            good_updates = [u for u, m in zip(updates, benign_mask) if m]
            good_nums = [n for n, m in zip(num_examples, benign_mask) if m]
        else:
            # Fallback to all if too few benign
            good_updates = updates
            good_nums = num_examples

        # Weighted average aggregation
        total_examples = sum(good_nums)
        if total_examples == 0:
            return None, {}

        aggregated = [
            np.zeros_like(layer) for layer in good_updates[0]
        ]
        for update, n in zip(good_updates, good_nums):
            for i, layer in enumerate(update):
                aggregated[i] += layer * n / total_examples

        metrics = {
            "num_benign": float(num_benign),
            "num_detected_malicious": float(num_malicious_detected),
            "detection_ratio": float(num_malicious_detected / len(preds)) if len(preds) > 0 else 0.0,
        }

        return ndarrays_to_parameters(aggregated), metrics
