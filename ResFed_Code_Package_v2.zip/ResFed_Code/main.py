"""
ResFed: Residual-based Robust Federated Aggregation
主运行脚本
"""
import argparse
import yaml
import torch
import flwr as fl
from flwr.server import ServerConfig
from flwr.common import ndarrays_to_parameters
import numpy as np
import os
from pathlib import Path

from models.cnn import SimpleCNN, FashionCNN
from utils.data_utils import get_dataset, partition_data, get_client_dataloader
from utils.attack_utils import get_malicious_clients
from client.flower_client import ResFedClient
from server.strategy import ResidualRobustStrategy


def get_evaluate_fn(testset, device, model_fn):
    """全局评估函数"""
    def evaluate(server_round, parameters, config):
        model = model_fn().to(device)
        params_dict = zip(model.state_dict().keys(), parameters)
        state_dict = {k: torch.tensor(v) for k, v in params_dict}
        model.load_state_dict(state_dict, strict=True)
        model.eval()

        testloader = torch.utils.data.DataLoader(testset, batch_size=128, shuffle=False)
        criterion = torch.nn.CrossEntropyLoss()
        correct, total, loss_sum = 0, 0, 0.0

        with torch.no_grad():
            for images, labels in testloader:
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)
                loss = criterion(outputs, labels)
                loss_sum += loss.item() * images.size(0)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        accuracy = correct / total
        avg_loss = loss_sum / total
        print(f"[Round {server_round}] Global Accuracy: {accuracy:.4f}, Loss: {avg_loss:.4f}")
        return avg_loss, {"accuracy": accuracy}
    return evaluate


def client_fn(context, trainset, client_indices, testset, device, malicious_ids, attack_type, local_epochs, lr, model_fn):
    cid = int(context.node_id) % len(client_indices)  # 简化处理
    trainloader = get_client_dataloader(trainset, client_indices[cid], batch_size=32)
    testloader = torch.utils.data.DataLoader(testset, batch_size=128, shuffle=False)
    model = model_fn()
    return ResFedClient(
        cid=cid,
        model=model,
        trainloader=trainloader,
        testloader=testloader,
        device=device,
        malicious_ids=malicious_ids,
        attack_type=attack_type,
        local_epochs=local_epochs,
        lr=lr,
    ).to_client()


def main(config_path="configs/default.yaml"):
    with open(config_path, "r") as f:
        cfg = yaml.safe_load(f)

    device = torch.device(cfg["device"] if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # 数据
    trainset, testset, num_channels = get_dataset(cfg["dataset"], cfg["data_dir"])
    client_indices = partition_data(trainset, num_clients=cfg["num_clients"], alpha=cfg["alpha"], seed=cfg["seed"])
    malicious_ids = get_malicious_clients(cfg["num_clients"], cfg["malicious_ratio"], seed=cfg["seed"])
    print(f"Malicious clients: {sorted(list(malicious_ids))}")

    # 模型
    if cfg["dataset"].lower() == "cifar10":
        model_fn = lambda: SimpleCNN(num_classes=10)
    else:
        model_fn = lambda: FashionCNN(num_classes=10)

    # 初始参数
    init_model = model_fn()
    initial_parameters = ndarrays_to_parameters(
        [val.cpu().numpy() for _, val in init_model.state_dict().items()]
    )

    # 策略
    strategy = ResidualRobustStrategy(
        contamination=cfg["contamination"],
        fraction_fit=cfg["fraction_fit"],
        min_fit_clients=max(2, int(cfg["num_clients"] * cfg["fraction_fit"] * 0.5)),
        min_available_clients=cfg["num_clients"],
        initial_parameters=initial_parameters,
        evaluate_fn=get_evaluate_fn(testset, device, model_fn),
        on_fit_config_fn=lambda rnd: {"local_epochs": cfg["local_epochs"]},
    )

    # 为了简化本地仿真，使用 start_simulation
    def client_fn_wrapper(context):
        return client_fn(
            context, trainset, client_indices, testset, device,
            malicious_ids, cfg["attack_type"], cfg["local_epochs"], cfg["lr"], model_fn
        )

    # 创建结果目录
    Path(cfg["save_dir"]).mkdir(parents=True, exist_ok=True)

    print("Starting Federated Learning Simulation...")
    history = fl.simulation.start_simulation(
        client_fn=client_fn_wrapper,
        num_clients=cfg["num_clients"],
        config=ServerConfig(num_rounds=cfg["num_rounds"]),
        strategy=strategy,
        client_resources={"num_cpus": 1, "num_gpus": 0.0},
    )

    print("Training finished.")
    print(f"Detection history: {strategy.detection_history}")
    return history


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/default.yaml")
    args = parser.parse_args()
    main(args.config)
