"""
ResFed 完整实验脚本（支持多种策略 + 自动保存CSV结果）
用法:
  python main_v2.py --config configs/default.yaml --strategy resfed
  python main_v2.py --config configs/default.yaml --strategy krum
  python main_v2.py --config configs/default.yaml --strategy median
  python main_v2.py --config configs/default.yaml --strategy trimmedmean
  python main_v2.py --config configs/default.yaml --strategy fedavg
"""
import argparse
import yaml
import torch
import flwr as fl
from flwr.server import ServerConfig
from flwr.common import ndarrays_to_parameters
import numpy as np
import os
import csv
from pathlib import Path
from datetime import datetime

from models.cnn import SimpleCNN, FashionCNN
from utils.data_utils import get_dataset, partition_data, get_client_dataloader
from utils.attack_utils import get_malicious_clients
from client.flower_client import ResFedClient
from server.strategy import ResidualRobustStrategy
from server.baselines import KrumStrategy, MedianStrategy, TrimmedMeanStrategy
from flwr.server.strategy import FedAvg


def get_evaluate_fn(testset, device, model_fn, history_list):
    def evaluate(server_round, parameters, config):
        model = model_fn().to(device)
        params_dict = zip(model.state_dict().keys(), parameters)
        state_dict = {k: torch.tensor(v) for k, v in params_dict}
        model.load_state_dict(state_dict, strict=True)
        model.eval()

        testloader = torch.utils.data.DataLoader(testset, batch_size=128, shuffle=False)
        criterion = torch.nn.CrossEntropyLoss()
        correct, total, loss_sum = 0, 0, 0.0

        with torch.no_grad():
            for images, labels in testloader:
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)
                loss = criterion(outputs, labels)
                loss_sum += loss.item() * images.size(0)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        accuracy = correct / total if total > 0 else 0.0
        avg_loss = loss_sum / total if total > 0 else 0.0
        print(f"[Round {server_round:3d}] Accuracy: {accuracy:.4f}  Loss: {avg_loss:.4f}")
        history_list.append({"round": server_round, "accuracy": accuracy, "loss": avg_loss})
        return avg_loss, {"accuracy": accuracy}
    return evaluate


def client_fn_factory(trainset, client_indices, testset, device, malicious_ids, attack_type, local_epochs, lr, model_fn):
    def client_fn(context):
        # Flower simulation node_id 从0开始
        cid = int(context.node_id) % len(client_indices)
        trainloader = get_client_dataloader(trainset, client_indices[cid], batch_size=32)
        testloader = torch.utils.data.DataLoader(testset, batch_size=128, shuffle=False)
        model = model_fn()
        return ResFedClient(
            cid=cid,
            model=model,
            trainloader=trainloader,
            testloader=testloader,
            device=device,
            malicious_ids=malicious_ids,
            attack_type=attack_type,
            local_epochs=local_epochs,
            lr=lr,
        ).to_client()
    return client_fn


def save_results_csv(history, detection_history, save_path, config, strategy_name):
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    with open(save_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["strategy", "dataset", "malicious_ratio", "attack_type", "alpha",
                         "round", "accuracy", "loss", "detected_malicious", "total_clients"])
        for h in history:
            det = next((d for d in detection_history if d.get("round") == h["round"]), {})
            writer.writerow([
                strategy_name,
                config.get("dataset", ""),
                config.get("malicious_ratio", ""),
                config.get("attack_type", ""),
                config.get("alpha", ""),
                h["round"],
                f"{h['accuracy']:.6f}",
                f"{h['loss']:.6f}",
                det.get("detected_malicious", ""),
                det.get("total_clients", "")
            ])
    print(f"Results saved to {save_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/default.yaml")
    parser.add_argument("--strategy", type=str, default="resfed",
                        choices=["resfed", "fedavg", "krum", "median", "trimmedmean"])
    parser.add_argument("--seed", type=int, default=None)
    args = parser.parse_args()

    with open(args.config, "r") as f:
        cfg = yaml.safe_load(f)

    if args.seed is not None:
        cfg["seed"] = args.seed

    device = torch.device("cuda" if torch.cuda.is_available() and cfg.get("device") == "cuda" else "cpu")
    print(f"Device: {device} | Strategy: {args.strategy}")

    # 数据
    trainset, testset, _ = get_dataset(cfg["dataset"], cfg.get("data_dir", "./data"))
    client_indices = partition_data(trainset, num_clients=cfg["num_clients"], alpha=cfg["alpha"], seed=cfg["seed"])
    malicious_ids = get_malicious_clients(cfg["num_clients"], cfg["malicious_ratio"], seed=cfg["seed"])
    print(f"Malicious clients ({len(malicious_ids)}): {sorted(list(malicious_ids))}")

    # 模型
    if cfg["dataset"].lower() == "cifar10":
        model_fn = lambda: SimpleCNN(num_classes=10)
    else:
        model_fn = lambda: FashionCNN(num_classes=10)

    init_model = model_fn()
    initial_parameters = ndarrays_to_parameters(
        [val.cpu().numpy() for _, val in init_model.state_dict().items()]
    )

    history_list = []
    evaluate_fn = get_evaluate_fn(testset, device, model_fn, history_list)

    # 选择策略
    common_kwargs = dict(
        fraction_fit=cfg["fraction_fit"],
        min_fit_clients=max(2, int(cfg["num_clients"] * cfg["fraction_fit"] * 0.5)),
        min_available_clients=cfg["num_clients"],
        initial_parameters=initial_parameters,
        evaluate_fn=evaluate_fn,
        on_fit_config_fn=lambda rnd: {"local_epochs": cfg["local_epochs"]},
    )

    if args.strategy == "resfed":
        strategy = ResidualRobustStrategy(contamination=cfg.get("contamination", 0.2), **common_kwargs)
    elif args.strategy == "krum":
        num_mal = max(1, int(cfg["num_clients"] * cfg["malicious_ratio"]))
        strategy = KrumStrategy(num_malicious=num_mal, multi_krum=True, **common_kwargs)
    elif args.strategy == "median":
        strategy = MedianStrategy(**common_kwargs)
    elif args.strategy == "trimmedmean":
        strategy = TrimmedMeanStrategy(beta=0.1, **common_kwargs)
    else:
        strategy = FedAvg(**common_kwargs)

    client_fn = client_fn_factory(
        trainset, client_indices, testset, device, malicious_ids,
        cfg["attack_type"], cfg["local_epochs"], cfg["lr"], model_fn
    )

    # 结果目录
    save_dir = Path(cfg.get("save_dir", "./results"))
    save_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = save_dir / f"{args.strategy}_m{cfg['malicious_ratio']}_a{cfg['alpha']}_{timestamp}.csv"

    print("Starting simulation...")
    fl.simulation.start_simulation(
        client_fn=client_fn,
        num_clients=cfg["num_clients"],
        config=ServerConfig(num_rounds=cfg["num_rounds"]),
        strategy=strategy,
        client_resources={"num_cpus": 1, "num_gpus": 0.0},
    )

    # 保存结果
    detection_history = getattr(strategy, "detection_history", [])
    save_results_csv(history_list, detection_history, str(csv_path), cfg, args.strategy)

    # 打印最终精度
    if history_list:
        final_acc = history_list[-1]["accuracy"]
        print(f"\n===== Final Accuracy: {final_acc:.4f} =====")
        print(f"Results CSV: {csv_path}")


if __name__ == "__main__":
    main()
