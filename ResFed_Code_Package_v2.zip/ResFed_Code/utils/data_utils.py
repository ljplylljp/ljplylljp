import torch
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms
import numpy as np
from collections import defaultdict


def get_dataset(dataset_name="cifar10", data_dir="./data"):
    if dataset_name.lower() == "cifar10":
        transform_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
        ])
        transform_test = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
        ])
        trainset = datasets.CIFAR10(root=data_dir, train=True, download=True, transform=transform_train)
        testset = datasets.CIFAR10(root=data_dir, train=False, download=True, transform=transform_test)
        num_channels = 3
    elif dataset_name.lower() == "fashionmnist":
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,)),
        ])
        trainset = datasets.FashionMNIST(root=data_dir, train=True, download=True, transform=transform)
        testset = datasets.FashionMNIST(root=data_dir, train=False, download=True, transform=transform)
        num_channels = 1
    else:
        raise ValueError(f"Unsupported dataset: {dataset_name}")
    return trainset, testset, num_channels


def partition_data(trainset, num_clients=100, alpha=0.5, seed=42):
    """Dirichlet non-IID partition"""
    np.random.seed(seed)
    num_classes = len(trainset.classes) if hasattr(trainset, 'classes') else 10
    labels = np.array(trainset.targets)
    
    client_indices = [[] for _ in range(num_clients)]
    for c in range(num_classes):
        class_indices = np.where(labels == c)[0]
        np.random.shuffle(class_indices)
        proportions = np.random.dirichlet([alpha] * num_clients)
        proportions = (proportions * len(class_indices)).astype(int)
        proportions[-1] = len(class_indices) - proportions[:-1].sum()
        
        start = 0
        for client_id, prop in enumerate(proportions):
            client_indices[client_id].extend(class_indices[start:start+prop])
            start += prop
    
    for i in range(num_clients):
        np.random.shuffle(client_indices[i])
    return client_indices


def get_client_dataloader(trainset, indices, batch_size=32, shuffle=True):
    subset = Subset(trainset, indices)
    return DataLoader(subset, batch_size=batch_size, shuffle=shuffle, num_workers=2, pin_memory=True)


def apply_label_flipping(labels, source=0, target=1, ratio=1.0):
    labels = labels.clone()
    mask = (labels == source)
    flip_idx = torch.where(mask)[0]
    flip_num = int(len(flip_idx) * ratio)
    if flip_num > 0:
        labels[flip_idx[:flip_num]] = target
    return labels


def apply_backdoor_trigger(images, labels, trigger_size=4, target_label=0):
    images = images.clone()
    labels = labels.clone()
    images[:, :, -trigger_size:, -trigger_size:] = 1.0
    labels[:] = target_label
    return images, labels
