import torch
import numpy as np
from copy import deepcopy


def label_flipping_attack(labels, source=0, target=1, ratio=1.0):
    """Label flipping attack"""
    labels = labels.clone()
    mask = (labels == source)
    flip_idx = torch.where(mask)[0]
    flip_num = int(len(flip_idx) * ratio)
    if flip_num > 0:
        labels[flip_idx[:flip_num]] = target
    return labels


def model_replacement_attack(local_params, global_params, scale=10.0):
    """
    Model replacement attack: scale the update so that after aggregation
    the global model is pulled toward the attacker's model.
    local_params / global_params: list of numpy arrays
    """
    malicious_params = []
    for lp, gp in zip(local_params, global_params):
        # malicious_update = scale * (local - global) + global
        malicious = scale * (lp - gp) + gp
        malicious_params.append(malicious)
    return malicious_params


def backdoor_attack_on_batch(images, labels, trigger_size=4, target_label=0):
    """Add backdoor trigger to a batch"""
    images = images.clone()
    labels = labels.clone()
    images[:, :, -trigger_size:, -trigger_size:] = 1.0
    labels[:] = target_label
    return images, labels


def get_malicious_clients(num_clients, malicious_ratio, seed=42):
    """Randomly select malicious client IDs"""
    np.random.seed(seed)
    num_malicious = int(num_clients * malicious_ratio)
    malicious_ids = np.random.choice(num_clients, num_malicious, replace=False).tolist()
    return set(malicious_ids)
