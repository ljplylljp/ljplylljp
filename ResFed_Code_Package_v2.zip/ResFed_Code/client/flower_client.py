import torch
import torch.nn as nn
from flwr.client import NumPyClient
from flwr.common import Context
from collections import OrderedDict
import numpy as np

from utils.attack_utils import label_flipping_attack, backdoor_attack_on_batch, model_replacement_attack


class ResFedClient(NumPyClient):
    def __init__(
        self,
        cid,
        model,
        trainloader,
        testloader,
        device,
        malicious_ids=None,
        attack_type="label_flip",
        local_epochs=5,
        lr=0.01,
        use_dp=False,
        epsilon=5.0,
    ):
        self.cid = int(cid)
        self.model = model.to(device)
        self.trainloader = trainloader
        self.testloader = testloader
        self.device = device
        self.malicious_ids = malicious_ids or set()
        self.attack_type = attack_type
        self.local_epochs = local_epochs
        self.lr = lr
        self.use_dp = use_dp
        self.epsilon = epsilon
        self.is_malicious = self.cid in self.malicious_ids

    def get_parameters(self, config):
        return [val.cpu().numpy() for _, val in self.model.state_dict().items()]

    def set_parameters(self, parameters):
        params_dict = zip(self.model.state_dict().keys(), parameters)
        state_dict = OrderedDict({k: torch.tensor(v) for k, v in params_dict})
        self.model.load_state_dict(state_dict, strict=True)

    def fit(self, parameters, config):
        self.set_parameters(parameters)
        global_params = parameters  # for model replacement

        optimizer = torch.optim.SGD(self.model.parameters(), lr=self.lr, momentum=0.9)
        criterion = nn.CrossEntropyLoss()

        self.model.train()
        for epoch in range(self.local_epochs):
            for images, labels in self.trainloader:
                images, labels = images.to(self.device), labels.to(self.device)

                # Apply attack if malicious
                if self.is_malicious:
                    if self.attack_type == "label_flip":
                        labels = label_flipping_attack(labels, source=0, target=1, ratio=1.0)
                    elif self.attack_type == "backdoor":
                        images, labels = backdoor_attack_on_batch(images, labels)

                optimizer.zero_grad()
                outputs = self.model(images)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

        # Model replacement attack after local training
        local_params = self.get_parameters(config={})
        if self.is_malicious and self.attack_type == "model_replacement":
            local_params = model_replacement_attack(local_params, global_params, scale=10.0)

        return local_params, len(self.trainloader.dataset), {"cid": self.cid, "malicious": self.is_malicious}

    def evaluate(self, parameters, config):
        self.set_parameters(parameters)
        self.model.eval()
        criterion = nn.CrossEntropyLoss()
        correct, total, loss_sum = 0, 0, 0.0

        with torch.no_grad():
            for images, labels in self.testloader:
                images, labels = images.to(self.device), labels.to(self.device)
                outputs = self.model(images)
                loss = criterion(outputs, labels)
                loss_sum += loss.item() * images.size(0)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        accuracy = correct / total if total > 0 else 0.0
        avg_loss = loss_sum / total if total > 0 else 0.0
        return avg_loss, total, {"accuracy": accuracy}
