#!/bin/bash
# 批量实验脚本示例

CONFIG_DIR=configs
RESULT_DIR=results

mkdir -p $RESULT_DIR

# 不同恶意比例实验
for ratio in 0.1 0.2 0.3 0.4
do
    echo "Running malicious_ratio=$ratio"
    # 可使用sed临时修改配置，或准备多个yaml
    python main.py --config $CONFIG_DIR/default.yaml
done

echo "All experiments finished."
